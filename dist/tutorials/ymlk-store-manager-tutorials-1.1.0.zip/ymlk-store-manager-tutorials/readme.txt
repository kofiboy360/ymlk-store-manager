=== YMLK Tutorial Recorder for Store Manager ===
Contributors: ymlktechnologies
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Records narrated video tutorials of the YMLK Store Manager, the screens a Shop Manager uses.

== Description ==
Pick a tutorial and the recorder walks through this site's real Store Manager, narrates each step with an OpenAI voice and saves an MP4 to the Media Library.

Tutorials: logging in, the Overview, adding a product, adding a product with sizes or colours, editing a product, deleting a product, managing orders, updating an order status, managing stock, customers, discount codes, exporting spreadsheets, new-order alerts and Help.

It only uses its own temporary test products and test order (hidden from the shop, no emails sent) and removes them afterwards. Requires YMLK Store Manager.

Find it under Store Manager > Tutorial Recorder (administrators only). If the original YMLK Tutorial Recorder has an OpenAI key saved, it is reused.

Developed by YMLK Technologies - https://ymlktechnologies.com

== Changelog ==
= 1.1.0 =
* New tutorials: customers, discount codes, spreadsheet export, new-order alerts and Help.
* Automatic updates from YMLK Technologies.
= 1.0.0 =
* First release.
