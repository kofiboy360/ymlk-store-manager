<?php
/**
 * Plugin Name: YMLK Tutorial Recorder for Store Manager
 * Description: Records personalised, narrated video tutorials of this site's YMLK Store Manager (the screens your Shop Manager uses). Recording happens in your Chrome tab; narration uses OpenAI text-to-speech.
 * Version: 1.0.0
 * Author: YMLK Technologies
 * Author URI: https://ymlktechnologies.com
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: ymlk-store-manager-tutorials
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class YMLK_SM_Tutorials {

	const VERSION   = '1.0.0';
	const OPT       = 'ymlk_smt_settings';
	const OLD_OPT   = 'ymlk_tr_settings'; // the original recorder's settings: its API key is reused if this one has none
	const SESSION   = 'ymlk_smt_session';
	const TEST_META = '_ymlk_smt_test';
	const VID_META  = '_ymlk_smt_tutorial';
	const CAP       = 'manage_options';
	const PAGE      = 'ymlk-sm-tutorials';

	/** Tutorial keys => titles (also used for video titles). */
	public static function tutorials() {
		return array(
			'login'           => array( 'title' => 'How to log in to your Store Manager', 'desc' => 'Log in from your website or your login link, and find your way around.' ),
			'overview'        => array( 'title' => 'Your Overview: how your shop is doing', 'desc' => 'Sales, orders, best sellers and items running low, for any period.' ),
			'add_product'     => array( 'title' => 'How to add a new product', 'desc' => 'Name, description, photos, price, stock, category and saving.' ),
			'add_options'     => array( 'title' => 'How to add a product with sizes or colours', 'desc' => 'Switch on options, tap the sizes and colours, set price and stock for all.' ),
			'edit_product'    => array( 'title' => 'How to edit a product', 'desc' => 'Quick price change from the list, and full editing of a product.' ),
			'delete_product'  => array( 'title' => 'How to delete a product', 'desc' => 'Move a product to the trash safely.' ),
			'manage_orders'   => array( 'title' => 'How to manage customer orders', 'desc' => 'Find an order, read it, contact the customer and add a note.' ),
			'order_status'    => array( 'title' => 'How to update an order status', 'desc' => 'Mark an order as Completed in one tap.' ),
			'inventory'       => array( 'title' => 'How to manage your stock', 'desc' => 'See stock per product, update sizes and colours, find items running low.' ),
		);
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 99 );
		add_action( 'admin_init', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );

		// Safety: never email anyone about tutorial test orders.
		add_action( 'woocommerce_email', array( __CLASS__, 'block_test_emails' ) );
		// Safety: a product created during the "add product" tutorial is flagged and hidden from the shop.
		add_action( 'save_post_product', array( __CLASS__, 'flag_tutorial_product' ), 20, 2 );
		// Login tutorial: shows this site's real login page (as a logged-out visitor sees it) inside the recording stage.
		add_action( 'admin_post_ymlk_smt_login_preview', array( __CLASS__, 'login_preview' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                            */
	/* ------------------------------------------------------------------ */

	public static function settings() {
		$s = get_option( self::OPT, array() );
		if ( ( ! is_array( $s ) || empty( $s['api_key'] ) ) && is_array( get_option( self::OLD_OPT ) ) ) {
			$old = get_option( self::OLD_OPT );
			$s   = is_array( $s ) ? $s : array();
			if ( ! empty( $old['api_key'] ) && empty( $s['cleared'] ) ) {
				$s['api_key'] = $old['api_key'];
				$s['voice']   = isset( $s['voice'] ) ? $s['voice'] : ( isset( $old['voice'] ) ? $old['voice'] : 'coral' );
			}
		}
		return wp_parse_args(
			is_array( $s ) ? $s : array(),
			array(
				'api_key' => '',
				'voice'   => 'coral',
				'model'   => 'gpt-4o-mini-tts',
			)
		);
	}

	public static function voices() {
		return array( 'coral', 'nova', 'shimmer', 'sage', 'alloy', 'ash', 'ballad', 'echo', 'fable', 'onyx', 'verse' );
	}

	public static function save_settings() {
		if ( empty( $_POST['ymlk_tr_save'] ) || ! current_user_can( self::CAP ) ) {
			return;
		}
		check_admin_referer( 'ymlk_tr_settings' );
		$s     = self::settings();
		$key   = isset( $_POST['ymlk_tr_api_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['ymlk_tr_api_key'] ) ) ) : '';
		$voice = isset( $_POST['ymlk_tr_voice'] ) ? sanitize_key( wp_unslash( $_POST['ymlk_tr_voice'] ) ) : 'coral';
		if ( '' !== $key && false === strpos( $key, '•' ) ) {
			$s['api_key'] = $key;
		}
		$s['cleared'] = ! empty( $_POST['ymlk_tr_clear_key'] );
		if ( $s['cleared'] ) {
			$s['api_key'] = '';
		}
		$s['voice'] = in_array( $voice, self::voices(), true ) ? $voice : 'coral';
		update_option( self::OPT, $s, false );
		add_settings_error( 'ymlk_tr', 'saved', 'Settings saved.', 'updated' );
	}

	/* ------------------------------------------------------------------ */
	/* Admin page                                                          */
	/* ------------------------------------------------------------------ */

	public static function menu() {
		$parent = class_exists( 'YSM_Plugin' ) ? 'ymlk-store-manager' : ( class_exists( 'WooCommerce' ) ? 'woocommerce' : 'tools.php' );
		add_submenu_page( $parent, 'Tutorial Recorder', 'Tutorial Recorder', self::CAP, self::PAGE, array( __CLASS__, 'page' ) );
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}
		$base = plugin_dir_url( __FILE__ );
		$dir  = plugin_dir_path( __FILE__ );
		wp_enqueue_style( 'ymlk-smt', $base . 'assets/admin.css', array(), self::VERSION . '.' . filemtime( $dir . 'assets/admin.css' ) );
		wp_enqueue_script( 'ymlk-smt', $base . 'assets/recorder.js', array(), self::VERSION . '.' . filemtime( $dir . 'assets/recorder.js' ), true );
		$s = self::settings();
		wp_localize_script(
			'ymlk-smt',
			'YMLKSMT',
			array(
				'rest'      => esc_url_raw( rest_url( 'ymlk-smt/v1/' ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'hasVoice'  => '' !== $s['api_key'],
				'site'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'tutorials' => self::tutorials(),
			)
		);
	}

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$s      = self::settings();
		$masked = $s['api_key'] ? substr( $s['api_key'], 0, 3 ) . str_repeat( '•', 12 ) . substr( $s['api_key'], -4 ) : '';
		$videos = self::videos();
		?>
		<div class="wrap ymlk-tr">
			<h1>Tutorial Recorder for Store Manager</h1>
			<?php settings_errors( 'ymlk_tr' ); ?>
			<?php if ( ! class_exists( 'YSM_Plugin' ) ) : ?>
				<div class="notice notice-error"><p><strong>YMLK Store Manager is not active.</strong> These tutorials show the Store Manager screens, so please install and activate it first.</p></div>
			<?php endif; ?>
			<p class="ymlk-tr-intro">Pick a tutorial and click <strong>Start Recording</strong>. The recorder walks through this site's real Store Manager, the screens your Shop Manager uses, narrates each step and saves an MP4 you can preview and download below. It only uses its own temporary test products and test order, and removes them afterwards.</p>
			<p class="ymlk-tr-tip">Use Chrome or Edge on a computer. When asked, choose <strong>This tab</strong> and keep <strong>Also share tab audio</strong> switched on. Make the browser window as large as you want the video. Press <kbd>Esc</kbd> to cancel a recording.</p>

			<div class="ymlk-tr-grid">
				<?php foreach ( self::tutorials() as $key => $t ) : ?>
					<div class="ymlk-tr-card" data-key="<?php echo esc_attr( $key ); ?>">
						<h2><?php echo esc_html( $t['title'] ); ?></h2>
						<p><?php echo esc_html( $t['desc'] ); ?></p>
						<button type="button" class="button button-primary ymlk-tr-start" data-key="<?php echo esc_attr( $key ); ?>">Start Recording</button>
					</div>
				<?php endforeach; ?>
			</div>

			<h2 class="ymlk-tr-h">Recorded videos</h2>
			<div class="ymlk-tr-videos">
				<?php if ( ! $videos ) : ?>
					<p class="description">No videos yet.</p>
				<?php endif; ?>
				<?php foreach ( $videos as $v ) : ?>
					<div class="ymlk-tr-video" data-id="<?php echo (int) $v['id']; ?>">
						<video src="<?php echo esc_url( $v['url'] ); ?>" controls preload="metadata"></video>
						<div class="ymlk-tr-video-meta">
							<strong><?php echo esc_html( $v['title'] ); ?></strong>
							<span><?php echo esc_html( $v['date'] ); ?> · <?php echo esc_html( $v['size'] ); ?></span>
							<div class="ymlk-tr-video-actions">
								<a class="button" href="<?php echo esc_url( $v['url'] ); ?>" download>Download</a>
								<button type="button" class="button-link ymlk-tr-del" data-id="<?php echo (int) $v['id']; ?>">Delete</button>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<h2 class="ymlk-tr-h">Voice settings</h2>
			<form method="post" class="ymlk-tr-settings">
				<?php wp_nonce_field( 'ymlk_tr_settings' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="ymlk_tr_api_key">OpenAI API key</label></th>
						<td>
							<input type="password" id="ymlk_tr_api_key" name="ymlk_tr_api_key" class="regular-text" value="<?php echo esc_attr( $masked ); ?>" autocomplete="off" placeholder="sk-...">
							<?php if ( $s['api_key'] ) : ?>
								<label><input type="checkbox" name="ymlk_tr_clear_key" value="1"> Remove key</label>
							<?php endif; ?>
							<p class="description">Used only to turn the narration script into speech. Without a key, videos are recorded with captions but no voice.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ymlk_tr_voice">Voice</label></th>
						<td>
							<select id="ymlk_tr_voice" name="ymlk_tr_voice">
								<?php foreach ( self::voices() as $voice ) : ?>
									<option value="<?php echo esc_attr( $voice ); ?>" <?php selected( $s['voice'], $voice ); ?>><?php echo esc_html( ucfirst( $voice ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>
				<p><button type="submit" name="ymlk_tr_save" value="1" class="button">Save settings</button></p>
			</form>
		</div>
		<?php
	}

	public static function videos() {
		$q   = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 50,
				'meta_key'       => self::VID_META, // phpcs:ignore
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$out = array();
		foreach ( $q as $p ) {
			$file  = get_attached_file( $p->ID );
			$out[] = array(
				'id'    => $p->ID,
				'title' => get_the_title( $p ),
				'url'   => wp_get_attachment_url( $p->ID ),
				'date'  => get_the_date( 'j M Y, H:i', $p ),
				'size'  => $file && file_exists( $file ) ? size_format( filesize( $file ), 1 ) : '',
			);
		}
		return $out;
	}

	/* ------------------------------------------------------------------ */
	/* REST API                                                            */
	/* ------------------------------------------------------------------ */

	public static function routes() {
		$perm = function () {
			return current_user_can( self::CAP );
		};
		register_rest_route( 'ymlk-smt/v1', '/prepare', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_prepare' ), 'permission_callback' => $perm ) );
		register_rest_route( 'ymlk-smt/v1', '/tts', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_tts' ), 'permission_callback' => $perm ) );
		register_rest_route( 'ymlk-smt/v1', '/upload', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_upload' ), 'permission_callback' => $perm ) );
		register_rest_route( 'ymlk-smt/v1', '/cleanup', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_cleanup' ), 'permission_callback' => $perm ) );
		register_rest_route( 'ymlk-smt/v1', '/video/(?P<id>\d+)', array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_video' ), 'permission_callback' => $perm ) );
	}

	/** Creates the safe test data a tutorial needs and returns the URLs it will visit. */
	public static function rest_prepare( WP_REST_Request $r ) {
		$key = sanitize_key( $r->get_param( 'tutorial' ) );
		if ( ! isset( self::tutorials()[ $key ] ) ) {
			return new WP_Error( 'ymlk_tr_bad', 'Unknown tutorial.', array( 'status' => 400 ) );
		}
		self::cleanup_test_data();
		set_transient( self::SESSION, $key, 30 * MINUTE_IN_SECONDS );

		if ( ! class_exists( 'YSM_Plugin' ) ) {
			return new WP_Error( 'ymlk_tr_nosm', 'YMLK Store Manager is not active on this site.', array( 'status' => 400 ) );
		}
		$app  = admin_url( 'admin.php?page=ymlk-store-manager' );
		$data = array(
			'tutorial'       => $key,
			'site'           => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'currency'       => function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol() ) : '$',
			'loginUrl'       => admin_url( 'admin-post.php?action=ymlk_smt_login_preview&page=login' ),
			'loginDisplay'   => wp_login_url(),
			'loginSpoken'    => self::spoken_path( wp_login_url() ),
			'homeUrl'        => home_url( '/' ),
			'homePreview'    => admin_url( 'admin-post.php?action=ymlk_smt_login_preview&page=home' ),
			'accountUrl'     => ( function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'myaccount' ) > 0 ) ? wc_get_page_permalink( 'myaccount' ) : '',
			'accountPreview' => admin_url( 'admin-post.php?action=ymlk_smt_login_preview&page=account' ),
			'app'            => $app,
			'sampleName'     => 'New Sample Product (Tutorial)',
			'optionsName'    => 'Sample Product with Options (Tutorial)',
		);
		if ( in_array( $key, array( 'edit_product', 'delete_product', 'manage_orders', 'order_status' ), true ) ) {
			$pid                 = self::create_test_product( 'delete_product' === $key ? 'Old Sample Product (Tutorial)' : 'Sample Product (Tutorial)' );
			$data['productId']   = $pid;
			$data['productName'] = get_the_title( $pid );
		}
		if ( 'inventory' === $key ) {
			$pid                 = self::create_test_variable( 'Sample Stock Product (Tutorial)' );
			$data['productId']   = $pid;
			$data['productName'] = get_the_title( $pid );
		}
		if ( in_array( $key, array( 'manage_orders', 'order_status' ), true ) ) {
			$order               = self::create_test_order( $data['productId'] );
			$data['orderId']     = $order->get_id();
			$data['orderNumber'] = $order->get_order_number();
			$data['customer']    = 'Sample Customer';
		}
		return rest_ensure_response( $data );
	}

	public static function rest_cleanup() {
		$n = self::cleanup_test_data();
		delete_transient( self::SESSION );
		return rest_ensure_response( array( 'removed' => $n ) );
	}

	/** Text-to-speech for one narration line, cached on disk so it is generated only once. */
	public static function rest_tts( WP_REST_Request $r ) {
		$s    = self::settings();
		$text = trim( wp_strip_all_tags( (string) $r->get_param( 'text' ) ) );
		if ( '' === $s['api_key'] ) {
			return new WP_Error( 'ymlk_tr_nokey', 'No OpenAI API key saved.', array( 'status' => 400 ) );
		}
		if ( '' === $text || strlen( $text ) > 1500 ) {
			return new WP_Error( 'ymlk_tr_text', 'Narration text is empty or too long.', array( 'status' => 400 ) );
		}
		$instructions = 'Speak like a warm, patient teacher showing a small-business owner how to use their website. Calm, clear, friendly and natural. Moderate pace.';
		$up           = wp_upload_dir();
		$dir          = trailingslashit( $up['basedir'] ) . 'ymlk-tr/tts/';
		$hash         = md5( $s['model'] . '|' . $s['voice'] . '|' . $instructions . '|' . $text );
		$file         = $dir . $hash . '.mp3';
		$url          = trailingslashit( $up['baseurl'] ) . 'ymlk-tr/tts/' . $hash . '.mp3';
		if ( file_exists( $file ) && filesize( $file ) > 1000 ) {
			return rest_ensure_response( array( 'url' => $url ) );
		}
		wp_mkdir_p( $dir );
		$res = wp_remote_post(
			'https://api.openai.com/v1/audio/speech',
			array(
				'timeout' => 25,
				'headers' => array(
					'Authorization' => 'Bearer ' . $s['api_key'],
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'           => $s['model'],
						'voice'           => $s['voice'],
						'input'           => $text,
						'instructions'    => $instructions,
						'response_format' => 'mp3',
					)
				),
			)
		);
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'ymlk_tr_tts', 'Voice service error: ' . $res->get_error_message(), array( 'status' => 502 ) );
		}
		$code = wp_remote_retrieve_response_code( $res );
		if ( 200 !== (int) $code ) {
			$body = json_decode( wp_remote_retrieve_body( $res ), true );
			$msg  = isset( $body['error']['message'] ) ? $body['error']['message'] : 'HTTP ' . $code;
			return new WP_Error( 'ymlk_tr_tts', 'Voice service error: ' . $msg, array( 'status' => 502 ) );
		}
		file_put_contents( $file, wp_remote_retrieve_body( $res ) ); // phpcs:ignore
		return rest_ensure_response( array( 'url' => $url ) );
	}

	/** Receives the finished recording and stores it in the Media Library. */
	public static function rest_upload( WP_REST_Request $r ) {
		$key = sanitize_key( $r->get_param( 'tutorial' ) );
		$t   = self::tutorials();
		if ( ! isset( $t[ $key ] ) || empty( $_FILES['video'] ) ) {
			return new WP_Error( 'ymlk_tr_bad', 'Missing video.', array( 'status' => 400 ) );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$ext                       = ( false !== strpos( (string) $_FILES['video']['type'], 'webm' ) ) ? 'webm' : 'mp4';
		$_FILES['video']['name']   = sanitize_file_name( 'tutorial-' . str_replace( '_', '-', $key ) . '-' . gmdate( 'Ymd-His' ) . '.' . $ext );
		$allow                     = function ( $m ) {
			$m['mp4|m4v'] = 'video/mp4';
			$m['webm']    = 'video/webm';
			return $m;
		};
		add_filter( 'upload_mimes', $allow );
		$id = media_handle_upload( 'video', 0, array( 'post_title' => $t[ $key ]['title'] ) );
		remove_filter( 'upload_mimes', $allow );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		update_post_meta( $id, self::VID_META, $key );
		return rest_ensure_response(
			array(
				'id'    => $id,
				'url'   => wp_get_attachment_url( $id ),
				'title' => get_the_title( $id ),
			)
		);
	}

	public static function rest_delete_video( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		if ( ! get_post_meta( $id, self::VID_META, true ) ) {
			return new WP_Error( 'ymlk_tr_bad', 'Not a tutorial video.', array( 'status' => 400 ) );
		}
		wp_delete_attachment( $id, true );
		return rest_ensure_response( array( 'deleted' => $id ) );
	}

	/* ------------------------------------------------------------------ */
	/* Safe test data                                                      */
	/* ------------------------------------------------------------------ */

	public static function hpos() {
		return class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	/** A photo from one of the shop's own products, so test products look real in the video (the original product is not changed). */
	private static function sample_image() {
		$ids = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 10, 'fields' => 'ids', 'meta_key' => '_thumbnail_id' ) ); // phpcs:ignore
		foreach ( $ids as $id ) {
			if ( ! get_post_meta( $id, self::TEST_META, true ) ) {
				return (int) get_post_thumbnail_id( $id );
			}
		}
		return 0;
	}

	private static function sample_category() {
		$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 1, 'exclude' => array( (int) get_option( 'default_product_cat' ) ) ) );
		return ( $cats && ! is_wp_error( $cats ) ) ? array( $cats[0]->term_id ) : array();
	}

	private static function create_test_product( $name, $stock = null ) {
		$p = new WC_Product_Simple();
		$p->set_name( $name );
		$p->set_status( 'publish' );
		$p->set_catalog_visibility( 'hidden' );
		$p->set_regular_price( '120' );
		// Realistic text so the video looks natural. The product itself is hidden from the shop and deleted after recording.
		$p->set_description( '<p>A customer favourite, made with care from quality materials. Practical, good-looking and easy to love.</p>' );
		$p->set_short_description( 'A customer favourite, made with care.' );
		if ( null !== $stock ) {
			$p->set_manage_stock( true );
			$p->set_stock_quantity( (int) $stock );
		}
		$p->update_meta_data( self::TEST_META, 1 );
		$p->set_category_ids( self::sample_category() );
		$img = self::sample_image();
		if ( $img ) {
			$p->set_image_id( $img );
		}
		return $p->save();
	}

	/** A hidden product with two of the shop's options (e.g. colours x sizes) and counted stock, some low and one sold out. */
	private static function create_test_variable( $name ) {
		$use = array();
		foreach ( wc_get_attribute_taxonomies() as $a ) {
			$tax   = wc_attribute_taxonomy_name( $a->attribute_name );
			$terms = taxonomy_exists( $tax ) ? get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'orderby' => 'menu_order', 'number' => 3 ) ) : array();
			if ( ! is_wp_error( $terms ) && count( $terms ) >= 2 ) {
				$use[] = array( 'id' => (int) $a->attribute_id, 'tax' => $tax, 'terms' => array_slice( $terms, 0, count( $use ) ? 3 : 2 ) );
			}
			if ( 2 === count( $use ) ) {
				break;
			}
		}
		if ( ! $use ) {
			return self::create_test_product( $name, 3 );
		}
		$p = new WC_Product_Variable();
		$p->set_name( $name );
		$p->set_status( 'publish' );
		$p->set_catalog_visibility( 'hidden' );
		$p->set_description( '<p>A customer favourite, made with care from quality materials.</p>' );
		$p->update_meta_data( self::TEST_META, 1 );
		$p->set_category_ids( self::sample_category() );
		$img = self::sample_image();
		if ( $img ) {
			$p->set_image_id( $img );
		}
		$attrs = array();
		foreach ( $use as $i => $u ) {
			$a = new WC_Product_Attribute();
			$a->set_id( $u['id'] );
			$a->set_name( $u['tax'] );
			$a->set_options( wp_list_pluck( $u['terms'], 'term_id' ) );
			$a->set_position( $i );
			$a->set_visible( true );
			$a->set_variation( true );
			$attrs[ $u['tax'] ] = $a;
		}
		$p->set_attributes( $attrs );
		$pid = $p->save();
		foreach ( $use as $u ) {
			wp_set_object_terms( $pid, wp_list_pluck( $u['terms'], 'term_id' ), $u['tax'] );
		}
		$combos = array( array() );
		foreach ( $use as $u ) {
			$next = array();
			foreach ( $combos as $c ) {
				foreach ( $u['terms'] as $t ) {
					$next[] = $c + array( $u['tax'] => $t->slug );
				}
			}
			$combos = $next;
		}
		$stock = array( 8, 2, 12, 0, 5, 1 );
		foreach ( $combos as $i => $c ) {
			$v = new WC_Product_Variation();
			$v->set_parent_id( $pid );
			$v->set_attributes( $c );
			$v->set_regular_price( '150' );
			$v->set_manage_stock( true );
			$v->set_stock_quantity( $stock[ $i % count( $stock ) ] );
			$v->save();
		}
		WC_Product_Variable::sync( $pid );
		return $pid;
	}

	private static function create_test_order( $product_id ) {
		$order = new WC_Order();
		$order->update_meta_data( self::TEST_META, 1 ); // set first so every email filter can see it
		$order->set_billing_first_name( 'Sample' );
		$order->set_billing_last_name( 'Customer' );
		$order->set_billing_email( 'sample.customer@example.com' );
		$order->set_billing_phone( '000 000 0000' );
		$order->set_billing_address_1( '12 Example Street' );
		$order->set_billing_city( 'Sample City' );
		$order->set_billing_country( WC()->countries->get_base_country() );
		$order->set_shipping_first_name( 'Sample' );
		$order->set_shipping_last_name( 'Customer' );
		$order->set_shipping_address_1( '12 Example Street' );
		$order->set_shipping_city( 'Sample City' );
		$order->set_shipping_country( WC()->countries->get_base_country() );
		$product = wc_get_product( $product_id );
		if ( $product ) {
			$order->add_product( $product, 2 );
		}
		$order->set_created_via( 'ymlk-tutorial' );
		$order->calculate_totals();
		$order->save();
		$order->set_status( 'processing' );
		$order->save();
		return $order;
	}

	/** Deletes every product and order this plugin created. Never touches anything else. */
	public static function cleanup_test_data() {
		$n = 0;
		$products = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'trash', 'future' ),
				'posts_per_page' => 50,
				'meta_key'       => self::TEST_META, // phpcs:ignore
				'fields'         => 'ids',
			)
		);
		foreach ( $products as $pid ) {
			$p = wc_get_product( $pid );
			if ( $p ) {
				$p->delete( true );
				$n++;
			}
		}
		if ( function_exists( 'wc_get_orders' ) ) {
			$orders = wc_get_orders(
				array(
					'limit'      => 50,
					'status'     => array_merge( array_keys( wc_get_order_statuses() ), array( 'trash' ) ),
					'meta_key'   => self::TEST_META, // phpcs:ignore
					'meta_value' => 1, // phpcs:ignore
				)
			);
			foreach ( $orders as $o ) {
				if ( $o->get_meta( self::TEST_META ) ) {
					$o->delete( true );
					$n++;
				}
			}
		}
		return $n;
	}

	public static function block_test_emails( $mailer ) {
		$cb = function ( $enabled, $object = null ) {
			if ( $object instanceof WC_Order && $object->get_meta( self::TEST_META ) ) {
				return false;
			}
			return $enabled;
		};
		foreach ( (array) $mailer->emails as $email ) {
			add_filter( 'woocommerce_email_enabled_' . $email->id, $cb, 999, 2 );
		}
	}

	/** While a tutorial session is running, a product saved with the tutorial sample name is flagged as test data and kept out of the shop. */
	public static function flag_tutorial_product( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || ! get_transient( self::SESSION ) ) {
			return;
		}
		if ( false === strpos( (string) $post->post_title, '(Tutorial)' ) ) {
			return;
		}
		update_post_meta( $post_id, self::TEST_META, 1 );
		$p = wc_get_product( $post_id );
		if ( $p && 'hidden' !== $p->get_catalog_visibility() ) {
			remove_action( 'save_post_product', array( __CLASS__, 'flag_tutorial_product' ), 20 );
			$p->set_catalog_visibility( 'hidden' );
			$p->save();
		}
	}

	/** How the login address sounds when read aloud, e.g. "forward slash shopowner". */
	public static function spoken_path( $url ) {
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$path = str_replace( 'wp-login.php', 'w p login dot p h p', $path );
		return 'forward slash ' . str_replace( array( '/', '-', '.' ), array( ' forward slash ', ' dash ', ' dot ' ), $path );
	}

	/**
	 * Outputs one of the site's own pages exactly as a logged-out visitor sees it: the home page (header with the
	 * account icon), the My Account page (WooCommerce login form) or the login page (custom address, logo and
	 * branding included). Login forms are disarmed: they cannot sign anyone in and never count as a login attempt.
	 */
	public static function login_preview() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed.' );
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'login'; // phpcs:ignore
		if ( 'home' === $page || 'account' === $page ) {
			$url = 'home' === $page ? home_url( '/' ) : wc_get_page_permalink( 'myaccount' );
			$res = wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 3 ) );
			$html = is_wp_error( $res ) ? '' : (string) wp_remote_retrieve_body( $res );
			if ( '' === $html ) {
				$html = '<!DOCTYPE html><html><head></head><body><p style="font:16px sans-serif;padding:40px">This page could not be loaded.</p></body></html>';
			}
			$html = preg_replace( '/<form([^>]*woocommerce-form-login[^>]*)>/i', '<form$1 onsubmit="return false">', $html );
			$html = preg_replace( '/<head([^>]*)>/i', '<head$1><base href="' . esc_url( home_url( '/' ) ) . '">', $html, 1 );
			nocache_headers();
			header( 'Content-Type: text/html; charset=utf-8' );
			echo $html; // phpcs:ignore -- the site's own page markup
			exit;
		}
		$res  = wp_remote_get( wp_login_url(), array( 'timeout' => 15, 'redirection' => 3 ) );
		$html = is_wp_error( $res ) ? '' : (string) wp_remote_retrieve_body( $res );
		if ( false === stripos( $html, 'loginform' ) ) {
			// Fallback: WordPress's standard login form markup.
			$html = '<!DOCTYPE html><html><head><meta charset="utf-8"><link rel="stylesheet" href="' . esc_url( includes_url( 'css/dashicons.min.css' ) ) . '"><link rel="stylesheet" href="' . esc_url( admin_url( 'css/login.min.css' ) ) . '"></head><body class="login wp-core-ui"><div id="login"><h1><a href="#">' . esc_html( get_bloginfo( 'name' ) ) . '</a></h1><form name="loginform" id="loginform" action="#" method="post"><p><label for="user_login">Username or Email Address</label><input type="text" name="log" id="user_login" class="input" size="20"></p><div class="user-pass-wrap"><label for="user_pass">Password</label><input type="password" name="pwd" id="user_pass" class="input" size="20"></div><p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"> <label for="rememberme">Remember Me</label></p><p class="submit"><input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In"></p></form></div></body></html>';
		}
		$html = preg_replace( '/(<form[^>]*id="loginform"[^>]*action=")[^"]*"/i', '$1#"', $html );
		$html = preg_replace( '/<head([^>]*)>/i', '<head$1><base href="' . esc_url( home_url( '/' ) ) . '">', $html, 1 );
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		echo $html; // phpcs:ignore -- the site's own login page markup
		exit;
	}
}

YMLK_SM_Tutorials::init();
