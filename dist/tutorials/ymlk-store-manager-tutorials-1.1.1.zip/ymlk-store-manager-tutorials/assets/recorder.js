/* YMLK Tutorial Recorder for Store Manager: drives this site's real Store Manager inside the page, records the tab, narrates each step. */
(function () {
	'use strict';
	var C = window.YMLKSMT;
	if (!C) { return; }

	var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
	var aborted = false;

	/* ---------------------------------------------------------------- API */
	function api(path, opts) {
		opts = opts || {};
		var headers = Object.assign({ 'X-WP-Nonce': C.nonce }, opts.headers || {});
		return fetch(C.rest + path, Object.assign({ credentials: 'same-origin' }, opts, { headers: headers }))
			.then(function (r) {
				return r.json().catch(function () { return {}; }).then(function (j) {
					if (!r.ok) { throw new Error(j.message || ('Request failed (' + r.status + ')')); }
					return j;
				});
			});
	}
	function post(path, body) {
		return api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
	}

	/* -------------------------------------------------------------- Panel */
	var panel = document.createElement('div');
	panel.className = 'ymlk-panel';
	panel.innerHTML = '<div class="ymlk-panel-card"><h2></h2><div class="ymlk-panel-body"></div><div class="ymlk-panel-actions"></div></div>';
	document.body.appendChild(panel);

	function showPanel(title, html, buttons) {
		panel.querySelector('h2').textContent = title;
		panel.querySelector('.ymlk-panel-body').innerHTML = html || '';
		var a = panel.querySelector('.ymlk-panel-actions');
		a.innerHTML = '';
		(buttons || []).forEach(function (b) {
			var el = document.createElement(b.href ? 'a' : 'button');
			el.className = 'button ' + (b.primary ? 'button-primary' : '');
			el.textContent = b.label;
			if (b.href) { el.href = b.href; if (b.download) { el.setAttribute('download', typeof b.download === 'string' ? b.download : ''); } }
			if (b.onClick) { el.addEventListener('click', b.onClick); }
			a.appendChild(el);
		});
		panel.classList.add('is-open');
	}
	function hidePanel() { panel.classList.remove('is-open'); }
	function esc(s) { var d = document.createElement('div'); d.textContent = String(s); return d.innerHTML; }

	/* -------------------------------------------------------------- Stage */
	var stage = document.createElement('div');
	stage.className = 'ymlk-stage';
	stage.innerHTML =
		'<div class="ymlk-addr"><span class="ymlk-dots"><i></i><i></i><i></i></span>' +
		'<span class="ymlk-url"><svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M12 2a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5zm-3 8V7a3 3 0 1 1 6 0v3H9z"/></svg><b></b></span></div>' +
		'<div class="ymlk-wrap"><iframe class="ymlk-frame" title="Tutorial"></iframe>' +
		'<div class="ymlk-hl"></div>' +
		'<div class="ymlk-cursor"><svg viewBox="0 0 24 24" width="28" height="28"><path d="M4 2l16 10.5-7.2 1.4L17 22l-3.2 1.4-4.1-8.2L4 20z" fill="#111" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg></div>' +
		'<div class="ymlk-caption"><span></span></div></div>';
	document.body.appendChild(stage);
	var frame = stage.querySelector('.ymlk-frame');
	var wrap = stage.querySelector('.ymlk-wrap');
	var cursor = stage.querySelector('.ymlk-cursor');
	var hl = stage.querySelector('.ymlk-hl');
	var caption = stage.querySelector('.ymlk-caption');
	var urlText = stage.querySelector('.ymlk-url b');
	var addrOverride = null;

	function setCaption(t) {
		caption.querySelector('span').textContent = t || '';
		caption.classList.toggle('is-on', !!t);
	}

	/* ------------------------------------------------- Frame helpers (h) */
	var h = {
		doc: function () { return frame.contentDocument; },
		win: function () { return frame.contentWindow; },
		loaded: function () {
			return new Promise(function (resolve) {
				frame.addEventListener('load', function on() { frame.removeEventListener('load', on); resolve(); });
			});
		},
		afterLoad: function () {
			var w = h.win(), d = h.doc();
			if (!w || !d) { return; }
			try {
				w.confirm = function () { return true; };
				w.alert = function () {};
				w.onbeforeunload = null;
				if (w.jQuery) { w.jQuery(w).off('beforeunload'); }
			} catch (e) { /* ignore */ }
			var st = d.createElement('style');
			st.textContent = '.notice:not(.notice-success):not(.updated):not(#message),.update-nag,#wpadminbar li[id*="novamira"],#screen-meta-links,.components-snackbar-list,.woocommerce-customer-effort-score,.woocommerce-layout__notice-list,.wc-admin-ces{display:none!important}html{scroll-behavior:smooth}';
			d.head && d.head.appendChild(st);
			d.addEventListener('keydown', onKey, true);
			try {
				w.print = function () {};
				// Show the Store Manager exactly as a Shop Manager sees it: no administrator-only links.
				st.textContent += '.ysm-side-foot a[href$="/wp-admin/"],.ysm-top-actions a[href$="/wp-admin/"],.ysm-btn[href*="wc-orders"],.ysm-btn[href*="post.php"]{display:none!important}';
				w.addEventListener('hashchange', function () { addrOverride = null; h.showUrl(); });
				var hello = function () { var e = d.querySelector('.ysm-hello h2'); if (e && /^Hello,/.test(e.textContent)) { e.textContent = 'Hello!'; } };
				hello();
				if (d.body && w.MutationObserver) { new w.MutationObserver(hello).observe(d.body, { childList: true, subtree: true }); }
			} catch (e2) { /* ignore */ }
			addrOverride = h._pendingAddr || null;
			h._pendingAddr = null;
			h.showUrl();
		},
		showUrl: function () {
			var u = addrOverride;
			if (!u) { try { u = h.win().location.href; } catch (e) { u = ''; } }
			urlText.textContent = u.replace(/^https?:\/\//, '').replace(/[?&]ymlk_tr_demo=1/, '');
		},
		addr: function (u) { addrOverride = u; h.showUrl(); },
		/* Loads a page and shows a different (the real, public) address in the address bar. */
		goAs: function (url, display) {
			return h.go(url, display);
		},
		/* Clicks a link without following it (used on the logged-out preview pages). */
		clickStay: function (target) {
			return h.el(target).then(function (el) {
				var stop = function (e) { e.preventDefault(); };
				el.addEventListener('click', stop, true);
				var f = el.form || (el.closest && el.closest('form'));
				if (f) { f.addEventListener('submit', stop, true); }
				return h.click(el);
			});
		},
		go: function (url, display) {
			var cur = '';
			try { cur = h.win().location.href; } catch (e) { /* ignore */ }
			if (cur === url) { if (display) { h.addr(display); } return Promise.resolve(); }
			if (cur && url.indexOf('#') > -1 && cur.split('#')[0] === url.split('#')[0]) {
				h.win().location.hash = url.split('#')[1];
				return sleep(300).then(function () { return h.ready(); });
			}
			var p = h.loaded();
			h._pendingAddr = display || null;
			urlText.textContent = (display || url).replace(/^https?:\/\//, '');
			frame.src = url;
			return p.then(function () { h.afterLoad(); return sleep(500); });
		},
		find: function (target) {
			var d = h.doc();
			if (!d) { return null; }
			if (target && target.nodeType) { return target; }
			if (typeof target === 'function') { return target(d); }
			var list = String(target).split('||');
			for (var i = 0; i < list.length; i++) {
				var el = d.querySelector(list[i].trim());
				if (el) { return el; }
			}
			return null;
		},
		visible: function (target) {
			var el = h.find(target);
			return !!(el && el.getClientRects().length && h.win().getComputedStyle(el).visibility !== 'hidden');
		},
		el: function (target, timeout) {
			var end = Date.now() + (timeout || 15000);
			return new Promise(function (resolve, reject) {
				(function poll() {
					if (aborted) { return reject(new Error('aborted')); }
					var el = h.find(target);
					if (el) { return resolve(el); }
					if (Date.now() > end) { return reject(new Error('Could not find ' + (typeof target === 'function' ? 'an element' : '"' + target + '"') + ' on ' + urlText.textContent)); }
					setTimeout(poll, 150);
				})();
			});
		},
		moveTo: function (el) {
			clearInterval(h._track);
			h._track = setInterval(function () { if (hl.style.opacity !== '0' && el.isConnected) { h.place(el, true); } }, 150);
			h.place(el, false);
		},
		place: function (el, onlyBox) {
			var r = h.rect(el);
			var x = Math.max(4, Math.min(wrap.clientWidth - 4, r.left + Math.min(r.width / 2, 160)));
			var y = Math.max(4, Math.min(wrap.clientHeight - 4, r.top + Math.min(r.height / 2, 40)));
			if (!onlyBox) { cursor.style.transform = 'translate(' + x + 'px,' + y + 'px)'; }
			hl.style.cssText = 'opacity:1;left:' + (r.left - 6) + 'px;top:' + (r.top - 6) + 'px;width:' + (r.width + 12) + 'px;height:' + (r.height + 12) + 'px';
		},
		/* For a row of links (like All | Processing) use the area the links cover, not the whole line. */
		rect: function (el) {
			var r = el.getBoundingClientRect();
			if (el.matches && el.matches('.subsubsub') && el.children.length) {
				var a = el.children[0].getBoundingClientRect(), b = el.children[el.children.length - 1].getBoundingClientRect();
				return { left: a.left, top: Math.min(a.top, b.top), width: b.right - a.left, height: Math.max(a.bottom, b.bottom) - Math.min(a.top, b.top) };
			}
			return r;
		},
		/* Draws a dropdown list on screen (native dropdown lists are never captured by tab recording). */
		openList: function (sel) {
			return h.el(sel).then(function (el) {
				var shown = (el.nextElementSibling && el.nextElementSibling.classList.contains('select2')) ? el.nextElementSibling : el;
				return h.point(shown, { hold: 300 }).then(function () {
					var r = shown.getBoundingClientRect();
					var box = document.createElement('div');
					box.className = 'ymlk-list';
					[].forEach.call(el.options || [], function (o) {
						var i = document.createElement('div');
						i.textContent = o.text;
						i.setAttribute('data-v', o.value);
						if (o.selected) { i.className = 'is-sel'; }
						box.appendChild(i);
					});
					box.style.left = r.left + 'px';
					box.style.top = (r.bottom + 2) + 'px';
					box.style.minWidth = r.width + 'px';
					cursor.classList.add('is-click');
					setTimeout(function () { cursor.classList.remove('is-click'); }, 350);
					h.unhighlight();
					wrap.appendChild(box);
					h._list = { box: box, el: el };
					return sleep(400);
				});
			});
		},
		pickList: function (re, fallback) {
			var L = h._list;
			if (!L) { return Promise.resolve(); }
			var target = null;
			[].forEach.call(L.box.children, function (i) { if (!target && re.test(i.textContent)) { target = i; } });
			if (!target && typeof fallback === 'number') { target = L.box.children[fallback] || null; }
			var close = function () { L.box.remove(); h._list = null; };
			if (!target) { close(); return Promise.resolve(); }
			var r = target.getBoundingClientRect(), wr = wrap.getBoundingClientRect();
			cursor.style.transform = 'translate(' + (r.left - wr.left + 40) + 'px,' + (r.top - wr.top + r.height / 2) + 'px)';
			return sleep(800).then(function () {
				target.classList.add('is-hover');
				return sleep(500);
			}).then(function () {
				cursor.classList.add('is-click');
				setTimeout(function () { cursor.classList.remove('is-click'); }, 350);
				L.el.value = target.getAttribute('data-v');
				L.el.dispatchEvent(new (h.win().Event)('change', { bubbles: true }));
				close();
				return sleep(600);
			});
		},
		/* Resolves once the element has stopped moving (smooth scrolling finished). */
		settle: function (el) {
			var last = null, same = 0, end = Date.now() + 2500;
			return new Promise(function (resolve) {
				(function check() {
					var r = el.getBoundingClientRect();
					var k = Math.round(r.top) + ':' + Math.round(r.left);
					same = (k === last) ? same + 1 : 0;
					last = k;
					if (same >= 3 || Date.now() > end) { return resolve(); }
					setTimeout(check, 80);
				})();
			});
		},
		point: function (target, opts) {
			opts = opts || {};
			return h.el(target).then(function (el) {
				el.scrollIntoView({ block: opts.block || 'center', behavior: 'smooth' });
				return sleep(150).then(function () { return h.settle(el); }).then(function () { h.moveTo(el); return sleep(opts.hold || 850); }).then(function () { return el; });
			});
		},
		unhighlight: function () { clearInterval(h._track); hl.style.opacity = '0'; },
		click: function (target) {
			return h.point(target, { hold: 600 }).then(function (el) {
				cursor.classList.add('is-click');
				setTimeout(function () { cursor.classList.remove('is-click'); }, 350);
				el.focus && el.focus();
				el.click();
				h.unhighlight();
				return sleep(350).then(function () { return el; });
			});
		},
		clickNav: function (target) {
			var p = h.loaded();
			return h.click(target).then(function () { return p; }).then(function () { h.afterLoad(); return sleep(600); });
		},
		type: function (target, text, opts) {
			opts = opts || {};
			return h.point(target, { hold: 350 }).then(function (el) {
				el.focus();
				var Ev = h.win().Event;
				if (opts.clear) { el.value = ''; el.dispatchEvent(new Ev('input', { bubbles: true })); }
				var chars = String(text).split('');
				var i = 0;
				return (function next() {
					if (aborted || i >= chars.length) {
						el.dispatchEvent(new Ev('change', { bubbles: true }));
						h.unhighlight();
						return sleep(250);
					}
					el.value += chars[i++];
					el.dispatchEvent(new Ev('input', { bubbles: true }));
					return sleep(opts.speed || 55).then(next);
				})();
			});
		},
		/* Types into the WordPress classic editor (TinyMCE) or its plain-text tab. */
		editor: function (id, text) {
			var w = h.win();
			var ed = w.tinymce && w.tinymce.get(id);
			if (ed && !ed.isHidden()) {
				return h.point('#wp-' + id + '-wrap', { hold: 300 }).then(function () {
					var words = text.split(' ');
					var i = 0;
					ed.focus();
					return (function next() {
						if (aborted || i >= words.length) { ed.save(); h.unhighlight(); return sleep(250); }
						i++;
						ed.setContent('<p>' + esc(words.slice(0, i).join(' ')) + '</p>');
						ed.selection.select(ed.getBody(), true);
						ed.selection.collapse(false);
						return sleep(130).then(next);
					})();
				});
			}
			return h.type('#' + id, text, { speed: 30 });
		},
		hover: function (target, cls) {
			return h.el(target).then(function (el) { el.classList.add(cls || 'visible'); return el; });
		},
		row: function (text) {
			return function (d) {
				var rows = d.querySelectorAll('#the-list tr, .wp-list-table tbody tr');
				for (var i = 0; i < rows.length; i++) { if (rows[i].textContent.indexOf(text) !== -1) { return rows[i]; } }
				return null;
			};
		},
		rowLink: function (text, sel) {
			return function (d) {
				var row = h.row(text)(d);
				return row ? row.querySelector(sel) : null;
			};
		},
		/* Store Manager: waits until a screen has finished loading (and optionally until an element is there). */
		ready: function (sel, timeout) {
			return h.until(function (d) {
				if (d.querySelector('#ysm-view .ysm-loading, .ysm-boot')) { return null; }
				return sel ? h.find(sel) : d.querySelector('#ysm-view > *');
			}, timeout).then(function () { return sleep(400); });
		},
		until: function (fn, timeout) {
			var end = Date.now() + (timeout || 15000);
			return new Promise(function (resolve, reject) {
				(function poll() {
					if (aborted) { return reject(new Error('aborted')); }
					var d = h.doc(), v = null;
					try { v = d && fn(d); } catch (e) { v = null; }
					if (v) { return resolve(v); }
					if (Date.now() > end) { return reject(new Error('The page did not finish loading on ' + urlText.textContent)); }
					setTimeout(poll, 150);
				})();
			});
		},
		/* Clicks something that opens another Store Manager screen, then waits for that screen. */
		clickView: function (target, readySel) {
			return h.click(target).then(function () { return sleep(300); }).then(function () { return h.ready(readySel); });
		},
		/* Types into the Store Manager description box (a rich-text area, not a normal input). */
		typeRich: function (target, text) {
			return h.point(target, { hold: 350 }).then(function (el) {
				var words = String(text).split(' '), i = 0, Ev = h.win().Event;
				el.focus();
				return (function next() {
					if (aborted || i >= words.length) { h.unhighlight(); return sleep(250); }
					i++;
					el.textContent = words.slice(0, i).join(' ');
					el.dispatchEvent(new Ev('input', { bubbles: true }));
					return sleep(120).then(next);
				})();
			});
		},
		/* The n-th element matching a selector (n starts at 0; -1 = last). */
		nth: function (sel, n) {
			return function (d) { var all = d.querySelectorAll(sel); return all[n < 0 ? all.length + n : n] || null; };
		},
		/* The white card that contains a given element. */
		card: function (sel) {
			return function (d) { var e = d.querySelector(sel); return e ? e.closest('.ysm-card') : null; };
		},
		/* The switch (label) that wraps a hidden checkbox. */
		label: function (sel) {
			return function (d) { var e = d.querySelector(sel); return e ? e.closest('label') : null; };
		},
		/* Sets a value that can't be typed letter by letter (e.g. a date), with the cursor pointing at it. */
		setValue: function (target, value) {
			return h.point(target, { hold: 500 }).then(function (el) {
				var Ev = h.win().Event;
				el.value = value;
				el.dispatchEvent(new Ev('input', { bubbles: true }));
				el.dispatchEvent(new Ev('change', { bubbles: true }));
				h.unhighlight();
				return sleep(500);
			});
		},
		wait: sleep
	};


	/* ----------------------------------------------------------- Narration */
	var audio = new Audio();
	var clips = {};
	function speak(text) {
		if (!text) { return Promise.resolve(); }
		var url = clips[text];
		if (!url) {
			var ms = Math.max(2200, text.split(' ').length * 330);
			return sleep(ms);
		}
		return new Promise(function (resolve) {
			var done = false;
			var finish = function () { if (!done) { done = true; resolve(); } };
			audio.onended = finish;
			audio.onerror = finish;
			audio.src = url;
			audio.play().catch(finish);
		});
	}
	function stopAudio() { try { audio.pause(); } catch (e) { /* ignore */ } }

	/* ----------------------------------------------------------- Tutorials */
	// Selectors are the YMLK Store Manager's own screens.
	function shown(sels) {
		return function (d) {
			for (var i = 0; i < sels.length; i++) { var e = d.querySelector(sels[i]); if (e && e.getClientRects().length) { return e; } }
			return null;
		};
	}
	var NAV = shown(['.ysm-nav', '.ysm-tabbar']);
	var FOOT = shown(['.ysm-side-foot', '.ysm-top-actions']);
	var LOGOUT = shown(['.ysm-side-foot a[href*="action=logout"]', '.ysm-top-actions a[href*="action=logout"]']);
	function firstCategory(d) {
		var boxes = d.querySelectorAll('#pe-cats input[type=checkbox]');
		for (var i = 0; i < boxes.length; i++) {
			if (!/uncategori[sz]ed/i.test(boxes[i].parentNode.textContent)) { return boxes[i]; }
		}
		return boxes[0] || null;
	}
	function saved(d) { var e = d.querySelector('#pe-state'); return e && /saved/i.test(e.textContent) ? e : null; }
	function save() { return h.click('#pe-save').then(function () { return h.until(saved, 30000); }).then(function () { h.showUrl(); return sleep(500); }); }
	function chip(opt, n) { return h.nth('[data-term^="' + opt + ':"]', n); }
	/* Waits for an element on a Store Manager list; if it is not there yet, reloads that list once. */
	function listed(sel, d, hash) {
		return h.ready(sel, 8000).catch(function () {
			if (aborted) { throw new Error('aborted'); }
			return h.go(d.app + '#/overview').then(function () { return h.go(d.app + hash); }).then(function () { return h.ready(sel); });
		});
	}

	var TUTORIALS = {
		login: function (d) {
			var base = (d.accountUrl || '').replace(/\/$/, '');
			var accountLink = function (dd) {
				if (!base) { return null; }
				var links = dd.querySelectorAll('a.ast-header-account-link, header a[href], #masthead a[href], .site-header a[href], a[href]');
				for (var i = 0; i < links.length; i++) {
					var href = (links[i].getAttribute('href') || '').replace(/\/$/, '');
					if (href === base && links[i].getClientRects().length) { return links[i]; }
				}
				return null;
			};
			var appHome = d.app + '#/overview';
			var steps = [];
			if (base) {
				steps.push(
					{ say: 'The easiest way to log in is from your own website. Go to your home page, and look at the top right corner, next to the cart. You will see the account icon.', need: accountLink, run: function () { return h.point(accountLink, { hold: 1400 }); } },
					{ say: 'Click the account icon. It opens your account page.', need: accountLink, run: function () { return h.clickStay(accountLink).then(function () { return h.goAs(d.accountPreview, d.accountUrl); }); } },
					{ say: 'Type the email address or username for your account into the first box.', need: '#username', run: function () { return h.type('#username', 'you@example.com'); } },
					{ say: 'Then type your password into the second box. It shows as dots, so nobody else can see it.', need: '#password', run: function () { return h.type('#password', 'MyPassword123'); } },
					{ say: 'If this is your own computer or phone, tick Remember me, so you stay logged in next time.', need: '#rememberme', run: function () { return h.click('#rememberme'); } },
					{ say: 'Now click Log in.', need: 'button[name=login]', run: function () { return h.clickStay('button[name=login]').then(function () { return h.go(appHome).then(function () { return h.ready(); }); }); } },
					{ say: 'You are now logged in, and you go straight to your Store Manager. This is where you run your shop.', run: function () { return h.go(appHome).then(function () { return h.ready('.ysm-hello'); }).then(function () { return h.point('.ysm-hello', { hold: 1200 }); }); } }
				);
			}
			steps.push(
				{ say: (base ? 'There is also a second way to log in. ' : '') + 'In your web browser, type your website address followed by ' + d.loginSpoken + '. You can see the full address at the top of the screen. It is a good idea to bookmark it.', run: function () {
					return h.goAs(d.loginUrl, d.loginDisplay).then(function () { return h.point('#loginform', { hold: 1200 }); });
				} },
				{ say: 'Enter the same email address or username, and your password.', need: '#user_login', run: function () {
					return h.type('#user_login', 'you@example.com', { speed: 40 }).then(function () { return h.type('#user_pass', 'MyPassword123', { speed: 40 }); });
				} },
				{ say: 'Then click Log In.', need: '#wp-submit', run: function () { return h.clickStay('#wp-submit').then(function () { return h.go(appHome).then(function () { return h.ready('.ysm-hello'); }); }); } },
				{ say: 'Either way, you land on your Store Manager. It works the same on your computer and on your phone.', run: function () { return h.go(appHome).then(function () { return h.ready('.ysm-hello'); }).then(function () { return h.point('.ysm-hello', { hold: 900 }); }).then(h.unhighlight); } },
				{ say: 'This is your menu. Overview shows how your shop is doing. Orders is where you see and update every purchase. Products is where you add and change what you sell. And Inventory is where you manage your stock.', need: NAV, run: function () { return h.point(NAV, { hold: 2500 }); } },
				{ say: 'View shop opens your website, so you can see it the way your customers do.', need: FOOT, run: function () { return h.point(FOOT, { hold: 1200 }); } },
				{ say: 'When you have finished, click Log out.', need: LOGOUT, run: function () { return h.point(LOGOUT, { hold: 1600 }); } }
			);
			return base ? { start: d.homePreview, addr: d.homeUrl, steps: steps } : { start: d.loginUrl, addr: d.loginDisplay, steps: steps };
		},

		overview: function (d) {
			return { start: d.app + '#/overview', steps: [
				{ say: 'This is your Overview. It shows how your shop is doing, at a glance.', run: function () { return h.ready('.ysm-hello').then(function () { return h.point('.ysm-hello', { hold: 900 }); }); } },
				{ say: 'These buttons choose the time period: today, the last seven days, this month, this year, or your own dates with Custom. Let us look at this year.', need: '[data-preset="year"]', run: function () {
					return h.point('.ysm-chips', { hold: 1600 }).then(function () { return h.click('[data-preset="year"]'); }).then(function () { return h.ready('.ysm-stats'); });
				} },
				{ say: 'When orders are waiting for you, a yellow message tells you how many, so nothing is missed. Tap it to see them.', need: '.ysm-alert', run: function () { return h.point('.ysm-alert', { hold: 1300 }); } },
				{ say: 'Here are your sales for the period, the number of orders, and the average amount each customer spent.', need: '.ysm-stats', run: function () { return h.point('.ysm-stats', { hold: 1300 }); } },
				{ say: 'The chart shows your sales day by day. Taller bars mean busier days.', need: '.ysm-chart', run: function () { return h.point(h.card('.ysm-chart'), { hold: 1300 }); } },
				{ say: 'Orders by status shows how many orders are processing, on hold, waiting for payment, completed or cancelled. Tap a box to see those orders.', need: '.ysm-statusgrid', run: function () { return h.point(h.card('.ysm-statusgrid'), { hold: 1300 }); } },
				{ say: 'Best sellers shows what sold the most in this period. Running low warns you when something is almost sold out, so you can restock in time.', need: '.ysm-grid2', run: function () { return h.point('.ysm-grid2', { hold: 1500 }); } },
				{ say: 'At the bottom are your latest orders. Tap any order to open it.', need: '.ysm-orders', run: function () { return h.point(h.nth('#ysm-view .ysm-card', -1), { hold: 1300 }); } }
			] };
		},

		add_product: function (d) {
			return { start: d.app + '#/products', steps: [
				{ say: 'This is your Products page. It lists everything you sell, with the price and stock.', run: function () { return h.ready('#p-list .ysm-prods, #p-list .ysm-empty').then(function () { return h.point('#p-list', { block: 'start', hold: 900 }); }); } },
				{ say: 'To add a new product, click Add product.', run: function () { return h.clickView('a[href="#/products/new"]', '#pe-name'); } },
				{ say: 'First, type the product name. Use the name your customers will recognise.', run: function () { return h.type('#pe-name', d.sampleName); } },
				{ say: 'Below that, describe the product: what it is, the size or material, and anything a customer should know before buying.', run: function () { return h.typeRich('#pe-desc', 'Made from soft, quality material that feels great and lasts. A customer favourite for every day.'); } },
				{ say: 'Click Add photos to upload pictures from your computer or phone, or choose ones you have already uploaded. The first photo is the main one customers see.', run: function () { return h.point('#pe-addphoto', { hold: 1600 }); } },
				{ say: 'Now enter the price. Just type the number, without the currency sign.', run: function () { return h.type('#pe-pricing [data-p="regular"]', '150'); } },
				{ say: 'If the product is on sale, put the lower price in Sale price. Leave it empty when there is no sale.', run: function () { return h.point('#pe-pricing [data-p="sale"]', { hold: 1300 }); } },
				{ say: 'Stock is how many you have. When it reaches zero, your shop shows Out of stock automatically. Leave it empty if you do not want to count.', run: function () { return h.type('#pe-pricing [data-p="stock"]', '10'); } },
				{ say: 'On the right, tick the category the product belongs to, so customers can find it in your shop.', need: firstCategory, run: function () { return h.click(firstCategory); } },
				{ say: 'Live in shop means customers can see it as soon as you save. Choose Hidden if you want to finish it later.', run: function () { return h.point('.ysm-seg', { hold: 1300 }); } },
				{ say: 'When everything looks right, click Save product.', run: save },
				{ say: 'Saved. Your new product is now in your shop.', run: function () { return h.point('#pe-state', { hold: 1500 }); } }
			] };
		},

		add_options: function (d) {
			return { start: d.app + '#/products', steps: [
				{ say: 'Some products come in different sizes or colours. To add one, start the same way: on your Products page, click Add product.', run: function () { return h.ready('#p-list .ysm-prods, #p-list .ysm-empty').then(function () { return h.clickView('a[href="#/products/new"]', '#pe-name'); }); } },
				{ say: 'Type the product name.', run: function () { return h.type('#pe-name', d.optionsName); } },
				{ say: 'Enter the price. This price is used for every size and colour, so you only type it once.', run: function () { return h.type('#pe-pricing [data-p="regular"]', '200'); } },
				{ say: 'Now go down to Options, and switch on: This product comes in different options.', run: function () { return h.click(h.label('#pe-hasopt')).then(function () { return h.ready('#pe-opts'); }); } },
				{ say: 'Click Add an option, and choose the first one, for example Colour.', need: '#pe-addopt', run: function () {
					return h.openList('#pe-addopt').then(function () { return h.pickList(/colou?r/i, 1); }).then(function () { return h.ready('[data-term^="0:"]'); });
				} },
				{ say: 'Now tap each colour you sell. The ones you choose get a tick.', need: '[data-term^="0:"]', run: function () {
					return h.click(chip(0, 0)).then(function () { return h.click(chip(0, 1)); });
				} },
				{ say: 'Then add the second option, for example Size, and tap the sizes you sell.', need: '#pe-addopt', run: function () {
					return h.openList('#pe-addopt').then(function () { return h.pickList(/size/i, 1); }).then(function () { return h.ready('[data-term^="1:"]'); })
						.then(function () { return h.click(chip(1, 0)); }).then(function () { return h.click(chip(1, 1)); }).then(function () { return h.click(chip(1, 2)); });
				} },
				{ say: 'If a colour or size you need is not in the list, type it in the New box at the end, and press Enter.', need: '[data-newterm="0"]', run: function () { return h.point('[data-newterm="0"]', { hold: 1300 }); } },
				{ say: 'Store Manager creates every combination for you straight away. Each row is one colour and size.', need: '.ysm-vars', run: function () { return h.point('.ysm-vars', { block: 'start', hold: 1600 }); } },
				{ say: 'To give every option the same stock, type the number here, and click Apply to all.', need: '#pe-allstock', run: function () {
					return h.type('#pe-allstock', '5').then(function () { return h.click('#pe-applystock'); });
				} },
				{ say: 'If one size costs more, type its price in its own row. Empty boxes use the price for all.', need: '.ysm-var[data-k]', run: function () { return h.type(h.nth('.ysm-var[data-k] [data-v="regular"]', -1), '220'); } },
				{ say: 'If you do not sell one of the combinations, just switch it off.', need: '.ysm-var[data-k]', run: function () { return h.click(h.nth('.ysm-var[data-k] label.ysm-switch', 1)); } },
				{ say: 'You can also add a photo for each colour. When a customer picks that colour, they see the right photo.', need: '.ysm-swatches', run: function () { return h.point('.ysm-sub', { hold: 1600 }); } },
				{ say: 'Tick the category, then click Save product.', run: function () {
					return (h.find(firstCategory) ? h.click(firstCategory) : Promise.resolve()).then(save);
				} },
				{ say: 'Saved. Customers can now choose their colour and size in your shop.', run: function () { return h.point('#pe-state', { hold: 1500 }); } }
			] };
		},

		edit_product: function (d) {
			var row = 'li[data-id="' + d.productId + '"]';
			return { start: d.app + '#/products', steps: [
				{ say: 'To change a product, go to Products, and type part of its name in the search box.', run: function () {
					return h.ready('#p-list .ysm-prods, #p-list .ysm-empty').then(function () { return h.type('#p-search', 'Sample Product'); }).then(function () { return h.ready(row); });
				} },
				{ say: 'For a quick change to the price or stock, click the pencil next to the product.', run: function () { return h.click(row + ' [data-quick]'); } },
				{ say: 'Type the new price, then click Save.', run: function () {
					return h.type(row + ' [data-f="regular"]', '135', { clear: true }).then(function () { return h.click(row + ' [data-qsave]'); })
						.then(function () { return h.until(function (dd) { var li = dd.querySelector(row); return li && !li.querySelector('.ysm-quick') ? li : null; }); });
				} },
				{ say: 'The new price is saved, and shows on your website straight away.', run: function () { return h.point(row, { hold: 1300 }); } },
				{ say: 'To change anything else, like the name, description, photos or category, click the product to open it.', run: function () { return h.clickView(row + ' a.ysm-prod', '#pe-name'); } },
				{ say: 'Everything about the product is here. Let us add a sale price, to show customers a discount.', run: function () { return h.type('#pe-pricing [data-p="sale"]', '110', { clear: true }); } },
				{ say: 'Then click Save product.', run: save },
				{ say: 'Saved. Customers now see the sale price, with the old price crossed out.', run: function () { return h.point('#pe-state', { hold: 1500 }); } }
			] };
		},

		delete_product: function (d) {
			var row = 'li[data-id="' + d.productId + '"]';
			return { start: d.app + '#/products', steps: [
				{ say: 'To delete a product, go to Products and search for it by name.', run: function () {
					return h.ready('#p-list .ysm-prods, #p-list .ysm-empty').then(function () { return h.type('#p-search', 'Old Sample'); }).then(function () { return h.ready(row); });
				} },
				{ say: 'Click the product to open it.', run: function () { return h.clickView(row + ' a.ysm-prod', '#pe-delete'); } },
				{ say: 'Then click Move to trash.', run: function () { return h.click('#pe-delete').then(function () { return h.el('.ysm-modal [data-a="yes"]'); }); } },
				{ say: 'Store Manager asks you to confirm, so nothing is deleted by accident. Click Move to trash.', run: function () {
					return h.point('.ysm-dialog', { hold: 900 }).then(function () { return h.click('.ysm-modal [data-a="yes"]'); }).then(function () { return h.ready('#p-list'); });
				} },
				{ say: 'The product is removed from your shop. If you ever delete one by mistake, contact your website developer. It can be brought back from the trash for a while.', run: function () {
					return h.type('#p-search', '', { clear: true }).then(function () { return sleep(700); }).then(function () { return h.ready('#p-list .ysm-prods, #p-list .ysm-empty'); }).then(function () { return h.point('#p-list', { block: 'start', hold: 1500 }); });
				} }
			] };
		},

		manage_orders: function (d) {
			var link = 'a[href="#/orders/' + d.orderId + '"]';
			return { start: d.app + '#/orders', steps: [
				{ say: 'This is your Orders page. Every purchase appears here, newest first, with the customer, the status and the total.', run: function () { return h.ready('#o-list .ysm-orders, #o-list .ysm-empty').then(function () { return h.point('#o-list', { block: 'start', hold: 1100 }); }); } },
				{ say: 'Use these tabs to show only some orders. For example, Processing shows orders that are paid and waiting for you to prepare.', run: function () { return h.click('[data-tab="processing"]').then(function () { return h.ready('#o-list .ysm-orders, #o-list .ysm-empty'); }); } },
				{ say: 'To find an order, type the customer name, phone number or order number in the search box.', run: function () {
					return h.type('#o-search', d.customer).then(function () { return listed(link, d, '#/orders'); });
				} },
				{ say: 'Click the order to open it.', run: function () { return h.clickView(link, '.ysm-order-grid'); } },
				{ say: 'At the top, you see the order number, its status, when it was placed, and how it was paid.', run: function () { return h.point('.ysm-pagehead', { hold: 1300 }); } },
				{ say: 'Items shows exactly what the customer bought, with the quantities and the total.', run: function () { return h.point(h.card('.ysm-items'), { hold: 1400 }); } },
				{ say: 'Customer shows who placed the order and where to deliver it. Call, WhatsApp and Email let you contact them in one tap. WhatsApp even starts the message for you.', run: function () { return h.point(h.card('.ysm-contact'), { hold: 1800 }); } },
				{ say: 'You can keep notes on an order, for example after you call the customer. Type your note, and click Add note. Only tick Send to customer if you want them to receive it.', run: function () {
					return h.type('#od-note', 'Called the customer to confirm the delivery address.', { speed: 35 })
						.then(function () { return h.click('#od-addnote'); })
						.then(function () { return h.until(function (dd) { var n = dd.querySelector('.ysm-notes li'); return n && /Called the customer/.test(n.textContent) ? n : null; }); });
				} },
				{ say: 'Your note is saved with the order, so you always have a record of what happened.', run: function () { return h.point('.ysm-notes li', { hold: 1300 }); } },
				{ say: 'Need a paper copy for the package? Click Print receipt.', run: function () { return h.point('#od-print', { hold: 1500 }); } }
			] };
		},

		order_status: function (d) {
			var link = 'a[href="#/orders/' + d.orderId + '"]';
			var badge = '.ysm-pagehead-title .ysm-badge';
			return { start: d.app + '#/orders', steps: [
				{ say: 'To update an order, open it from your Orders page.', run: function () { return listed(link, d, '#/orders').then(function () { return h.clickView(link, '.ysm-order-grid'); }); } },
				{ say: 'The status tells you, and your customer, where the order is. Processing means it has been paid, and you need to prepare it.', run: function () { return h.point(badge, { hold: 1500 }); } },
				{ say: 'When you have delivered it, click Mark as Completed.', need: '[data-set="completed"]', run: function () {
					return h.click('[data-set="completed"]').then(function () { return h.until(function (dd) { var b = dd.querySelector(badge); return b && /complet/i.test(b.textContent) ? b : null; }); });
				} },
				{ say: 'Done. The order is now Completed, and your customer automatically receives an email to let them know.', run: function () { return h.point(badge, { hold: 1500 }); } },
				{ say: 'For other changes, like On hold, Cancelled or Refunded, choose the status from this list, then click Update.', run: function () {
					return h.openList('#od-status').then(function () { return sleep(1800); }).then(function () { return h.pickList(/complet/i); }).then(function () { return h.point('#od-save', { hold: 1200 }); });
				} }
			] };
		},

		inventory: function (d) {
			var row = 'li[data-pid="' + d.productId + '"]';
			var outCell = function (dd) { return dd.querySelector(row + ' td.is-out input') || dd.querySelector(row + ' [data-cell]'); };
			return { start: d.app + '#/inventory', steps: [
				{ say: 'Inventory shows the stock of everything you sell, with one row for each product.', run: function () { return h.ready('#i-list .ysm-inv, #i-list .ysm-empty').then(function () { return h.point('#i-list', { block: 'start', hold: 1200 }); }); } },
				{ say: 'Type a product name in the search box to find it quickly.', run: function () { return h.type('#i-search', 'Sample Stock').then(function () { return h.ready(row); }); } },
				{ say: 'Each row shows how many you have in total. Red and yellow labels tell you how many options are sold out or running low.', run: function () { return h.point(row, { hold: 1500 }); } },
				{ say: 'Click the product to see the stock of each size and colour.', need: row + ' [data-toggle]', run: function () { return h.click(row + ' [data-toggle]').then(function () { return h.el(row + ' .ysm-matrix'); }); } },
				{ say: 'Each box is one option. Yellow means it is running low. Red means it is sold out.', need: row + ' .ysm-matrix', run: function () { return h.point(row + ' .ysm-matrix', { hold: 1800 }); } },
				{ say: 'To change the stock, click a box, type the new number and press Enter. It saves straight away, and the shop updates too.', need: row + ' [data-cell]', run: function () {
					return h.type(outCell, '6', { clear: true }).then(function () { return sleep(1200); });
				} },
				{ say: 'To give every option the same stock, type the number here and click Apply.', need: row + ' [data-all]', run: function () {
					return h.type(row + ' [data-all]', '10').then(function () { return h.click(row + ' [data-applyall]'); }).then(function () { return sleep(2500); });
				} },
				{ say: 'For a product without sizes or colours, use the minus and plus buttons on its row, or type the number.', need: '.ysm-stepper', run: function () { return h.point('.ysm-stepper', { hold: 1300 }); } },
				{ say: 'Running low and Out of stock show only the products that need restocking, so you know exactly what to order.', run: function () { return h.point('.ysm-tabs', { hold: 1700 }); } }
			] };
		},
		customers: function (d) {
			var link = 'a[href="#/customers/' + encodeURIComponent(d.customerEmail) + '"]';
			return { start: d.app + '#/customers', steps: [
				{ say: 'Customers shows everyone who has ordered from your shop, newest first, with how much each person has spent.', run: function () { return h.ready('#c-list .ysm-people, #c-list .ysm-empty').then(function () { return h.point('#c-list', { block: 'start', hold: 1300 }); }); } },
				{ say: 'These tabs sort the list. Top spenders shows your best customers first. Most orders shows who buys most often.', run: function () { return h.click('[data-tab="spent"]').then(function () { return h.ready('#c-list .ysm-people, #c-list .ysm-empty'); }); } },
				{ say: 'To find someone, type their name, phone number or email in the search box.', run: function () {
					return h.type('#c-search', 'Sample').then(function () { return listed(link, d, '#/customers'); });
				} },
				{ say: 'Click a customer to see everything about them.', run: function () { return h.clickView(link, '.ysm-stats-4'); } },
				{ say: 'Here you see how much they have spent in total, how many orders they placed, their average order, and when they first bought from you.', run: function () { return h.point('.ysm-stats-4', { hold: 1700 }); } },
				{ say: 'Call, WhatsApp or Email them in one tap. For example, to thank them, or to tell them about new arrivals.', run: function () { return h.point('.ysm-contact', { hold: 1600 }); } },
				{ say: 'Below are all of their orders. Tap any order to open it.', run: function () { return h.point(h.card('#ysm-view .ysm-orders'), { hold: 1400 }); } },
				{ say: 'Back on the Customers page, the Export button downloads your whole customer list as a spreadsheet.', run: function () {
					return h.clickView('a.ysm-back', '#c-list').then(function () { return h.point('#c-export', { hold: 1400 }); });
				} }
			] };
		},

		discounts: function (d) {
			var statusSeg = function (dd) { var b = dd.querySelector('[data-on]'); return b ? b.parentNode : null; };
			return { start: d.app + '#/coupons', steps: [
				{ say: 'Discounts is where you create codes that give your customers money off. Customers type the code at checkout.', run: function () { return h.ready('#d-list .ysm-coupons, #d-list .ysm-empty').then(function () { return h.point('#d-list', { block: 'start', hold: 1200 }); }); } },
				{ say: 'To make a new one, click Create discount.', run: function () { return h.clickView('a[href="#/coupons/new"]', '#cp-code'); } },
				{ say: 'First, the code itself. Type something short and easy to remember, like ' + d.couponCode.split('').join(' ') + '. Or click Generate for a random code.', run: function () { return h.type('#cp-code', d.couponCode, { clear: true }); } },
				{ say: 'Choose the kind of discount: a percentage off, or an amount off.', run: function () { return h.point('#cp-types', { hold: 1300 }); } },
				{ say: 'Then type how much. Here, ten percent off.', run: function () { return h.type('#cp-amount', '10'); } },
				{ say: 'Switch on Free delivery if the code should also give free delivery.', run: function () { return h.point(h.label('#cp-free'), { hold: 1300 }); } },
				{ say: 'The rules are all optional. A minimum order means the code only works when the order is at least this amount.', run: function () { return h.type('#cp-min', '200'); } },
				{ say: 'You can also choose when the code ends, how many times it can be used in total, and how many times each customer can use it.', run: function () {
					return h.setValue('#cp-exp', d.couponEnds).then(function () { return h.type('#cp-per', '1'); });
				} },
				{ say: 'The summary shows exactly what your customers get, in plain words, so you can check it before saving.', run: function () { return h.point('.ysm-summary', { hold: 1800 }); } },
				{ say: 'Click Save discount.', run: function () {
					return h.click('#cp-save').then(function () { return h.until(function (dd) { var e = dd.querySelector('#cp-state'); return e && /saved/i.test(e.textContent) ? e : null; }, 30000); }).then(function () { h.showUrl(); return sleep(500); });
				} },
				{ say: 'Your code is ready. Click Copy code to paste it anywhere, or Share on WhatsApp to send it to your customers.', run: function () { return h.point('.ysm-summary .ysm-row', { hold: 1700 }); } },
				{ say: 'To pause a discount without deleting it, choose Off, and save. Customers cannot use it until you switch it back on.', run: function () { return h.point(statusSeg, { hold: 1600 }); } },
				{ say: 'Back on the Discounts page, you see all your codes, and how many times each one has been used.', run: function () {
					return h.clickView('a.ysm-back', '#d-list .ysm-coupons, #d-list .ysm-empty').then(function () { return h.point('#d-list', { block: 'start', hold: 1500 }); });
				} }
			] };
		},

		export: function (d) {
			return { start: d.app + '#/orders', steps: [
				{ say: 'You can download your orders as a spreadsheet, to open in Excel or Google Sheets. It is useful for your records, or for your accountant.', run: function () { return h.ready('#o-list .ysm-orders, #o-list .ysm-empty').then(function () { return h.point('#o-export', { hold: 1400 }); }); } },
				{ say: 'On the Orders page, click Export.', run: function () { return h.click('#o-export').then(function () { return h.el('#ex-go'); }); } },
				{ say: 'Choose the period, for example Last month.', run: function () { return h.click('[data-per="lastmonth"]'); } },
				{ say: 'You can download all orders, or only some, for example only Completed orders.', run: function () { return h.point('#ex-status', { hold: 1400 }); } },
				{ say: 'Then click Download. The file is saved to your computer or phone, in your Downloads.', run: function () {
					return h.point('#ex-go', { hold: 1500 }).then(function () { return h.click('.ysm-modal [data-close]'); });
				} },
				{ say: 'The same Export button is on the Customers page, for your customer list.', run: function () { return h.go(d.app + '#/customers').then(function () { return h.ready('#c-export'); }).then(function () { return h.point('#c-export', { hold: 1300 }); }); } },
				{ say: 'And on the Inventory page, for a list of all your products, with prices and stock.', run: function () { return h.go(d.app + '#/inventory').then(function () { return h.ready('#i-export'); }).then(function () { return h.point('#i-export', { hold: 1400 }); }); } }
			] };
		},

		alerts: function (d) {
			var ordersNav = function (dd) { var n = NAV(dd); return n ? n.querySelector('[data-nav="orders"]') : null; };
			return { start: d.app + '#/orders', steps: [
				{ say: 'Store Manager tells you about new orders as they arrive. The red number next to Orders shows how many orders are waiting for you.', run: function () { return h.ready('#o-list .ysm-orders, #o-list .ysm-empty').then(function () { return h.point(ordersNav, { hold: 1600 }); }); } },
				{ say: 'To set up your alerts, click Alerts on the Orders page.', run: function () { return h.click('#o-alerts').then(function () { return h.el('#al-test'); }); } },
				{ say: 'Keep Store Manager open on your computer or phone. When a customer pays, you hear a chime, and a message pops up. Click Test the alert to see it.', run: function () {
					return h.click('#al-test').then(function () { return h.el('.ysm-alertpop'); }).then(function () { return h.point('.ysm-alertpop', { hold: 1500 }); });
				} },
				{ say: 'Click Open to go straight to the new order.', run: function () {
					return h.point('.ysm-alertpop .ysm-btn', { hold: 1300 }).then(function () { var x = h.find('.ysm-alertpop .ysm-iconbtn'); if (x) { x.click(); } });
				} },
				{ say: 'Play a sound switches the chime on or off.', run: function () { return h.point(h.label('#al-sound'), { hold: 1300 }); } },
				{ say: 'Desktop notifications show the alert even when you are working in another tab. Switch it on, and click Allow when your browser asks.', need: '#al-notify', run: function () { return h.point(h.label('#al-notify'), { hold: 1600 }); } },
				{ say: 'You can also get an email for every new order. Type one or more email addresses here, then click Save email settings.', need: '#al-emails', run: function () {
					return h.point('#al-emails', { hold: 1300 }).then(function () { return h.point('#al-save', { hold: 1100 }); });
				} },
				{ say: 'When you are done, close this window.', run: function () { return h.click('.ysm-modal [data-close]'); } }
			] };
		},

		help: function (d) {
			return { start: d.app + '#/help', steps: [
				{ say: 'Help has short videos that show you how to use your Store Manager, step by step.', run: function () { return h.ready('.ysm-support').then(function () { return h.point('.ysm-hello', { hold: 1300 }); }); } },
				{ say: 'Tap any video to play it. You can watch them again whenever you need a reminder.', need: '.ysm-video', run: function () { return h.point('.ysm-video', { hold: 1600 }); } },
				{ say: 'If you need help with something else, contact your web developer from here.', run: function () { return h.point('.ysm-support', { hold: 1700 }); } },
				{ say: 'On a phone, you find Help, Customers and Discounts under More, at the bottom of the screen.', run: function () { return h.point(FOOT, { hold: 1200 }); } }
			] };
		}
	};

	/* ------------------------------------------------------------ Recorder */
	var recorder = null, chunks = [], stream = null;

	function pickMime() {
		var types = ['video/mp4;codecs=avc1.42E01F,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm'];
		for (var i = 0; i < types.length; i++) {
			if (window.MediaRecorder && MediaRecorder.isTypeSupported(types[i])) { return types[i]; }
		}
		return '';
	}

	function capture() {
		return navigator.mediaDevices.getDisplayMedia({
			video: { displaySurface: 'browser', frameRate: 30, width: { ideal: 1920 }, height: { ideal: 1080 } },
			audio: { suppressLocalAudioPlayback: false, echoCancellation: false, noiseSuppression: false, autoGainControl: false },
			preferCurrentTab: true,
			selfBrowserSurface: 'include',
			surfaceSwitching: 'exclude',
			systemAudio: 'exclude'
		});
	}

	function onKey(e) {
		if (e.key === 'Escape' && stage.classList.contains('is-on')) { e.preventDefault(); cancel(); }
	}
	document.addEventListener('keydown', onKey, true);

	function cancel() {
		if (aborted) { return; }
		aborted = true;
		stopAudio();
	}

	function closeStage() {
		stage.classList.remove('is-on');
		document.documentElement.classList.remove('ymlk-lock');
		setCaption('');
		h.unhighlight();
		frame.src = 'about:blank';
		if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
	}

	function cleanup() { return post('cleanup').catch(function () { /* ignore */ }); }

	function start(key) {
		var t = C.tutorials[key];
		aborted = false;
		showPanel('Preparing: ' + t.title, '<p>Creating safe test data…</p>');
		var data, plan;
		post('prepare', { tutorial: key })
			.then(function (res) {
				data = res;
				plan = TUTORIALS[key](data);
				if (!C.hasVoice) { return; }
				var lines = plan.steps.map(function (s) { return s.say; }).filter(Boolean);
				var i = 0;
				return lines.reduce(function (p, line) {
					return p.then(function () {
						i++;
						showPanel('Preparing: ' + t.title, '<p>Generating narration ' + i + ' of ' + lines.length + '…</p>');
						if (clips[line]) { return; }
						return post('tts', { text: line }).then(function (r) {
							clips[line] = r.url;
							var a = new Audio(); a.preload = 'auto'; a.src = r.url;
						});
					});
				}, Promise.resolve());
			})
			.then(function () {
				showPanel('Ready to record',
					'<p><strong>' + esc(t.title) + '</strong></p>' +
					'<ol><li>Click <strong>Record now</strong>.</li><li>Chrome asks what to share: choose <strong>This tab</strong> and keep <strong>Also share tab audio</strong> switched on.</li><li>Sit back. Don\'t click or scroll until it finishes. Press <kbd>Esc</kbd> to cancel.</li></ol>' +
					(C.hasVoice ? '' : '<p class="ymlk-warn">No OpenAI key is saved, so this video will have captions but no voice.</p>'),
					[
						{ label: 'Record now', primary: true, onClick: function () { record(key, data, plan); } },
						{ label: 'Test run (no recording)', onClick: function () { record(key, data, plan, true); } },
						{ label: 'Cancel', onClick: function () { hidePanel(); cleanup(); } }
					]);
			})
			.catch(function (e) {
				cleanup();
				showPanel('Could not prepare the tutorial', '<p>' + esc(e.message) + '</p>', [{ label: 'Close', onClick: hidePanel }]);
			});
	}

	function record(key, data, plan, dry) {
		var t = C.tutorials[key];
		var mime = pickMime();
		aborted = false;
		if (!dry && (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia || !mime)) {
			showPanel('Browser not supported', '<p>Please use Chrome or Edge on a computer.</p>', [{ label: 'Close', onClick: function () { hidePanel(); cleanup(); } }]);
			return;
		}
		(dry ? Promise.resolve(null) : capture()).then(function (s) {
			stream = s;
			if (dry) {
				hidePanel();
				document.documentElement.classList.add('ymlk-lock');
				stage.classList.add('is-on');
				return h.go(plan.start, plan.addr);
			}
			var vt = s.getVideoTracks()[0];
			var settings = vt.getSettings ? vt.getSettings() : {};
			if (settings.displaySurface && settings.displaySurface !== 'browser') {
				throw new Error('Please choose "This tab" (not a window or the entire screen) and try again.');
			}
			if (C.hasVoice && !s.getAudioTracks().length) {
				throw new Error('Tab audio was not shared, so the narration would be silent. Try again and keep "Also share tab audio" switched on.');
			}
			vt.addEventListener('ended', cancel);
			hidePanel();
			document.documentElement.classList.add('ymlk-lock');
			stage.classList.add('is-on');
			cursor.style.transform = 'translate(' + (wrap.clientWidth * 0.6) + 'px,' + (wrap.clientHeight * 0.45) + 'px)';
			return h.go(plan.start, plan.addr);
		}).then(function () {
			if (plan.addr) { h.addr(plan.addr); }
			if (stream && window.CropTarget && stream.getVideoTracks()[0].cropTo) {
				return CropTarget.fromElement(stage).then(function (ct) { return stream.getVideoTracks()[0].cropTo(ct); }).catch(function () { /* optional */ });
			}
		}).then(function () {
			chunks = [];
			if (dry) { recorder = null; return sleep(300); }
			recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2500000, audioBitsPerSecond: 128000 });
			recorder.ondataavailable = function (e) { if (e.data && e.data.size) { chunks.push(e.data); } };
			recorder.start(1000);
			return sleep(700);
		}).then(function () {
			return plan.steps.reduce(function (p, step) {
				return p.then(function () {
					if (aborted) { return; }
					if (step.need && !h.visible(step.need)) { return; } // box hidden on this site: skip the step
					setCaption(step.say);
					return Promise.all([speak(step.say), step.run ? step.run() : null]).then(function () { return sleep(step.pause || 450); });
				});
			}, Promise.resolve());
		}).then(function () {
			setCaption('');
			h.unhighlight();
			return sleep(aborted ? 0 : 900);
		}).then(function () {
			return new Promise(function (resolve) {
				if (!recorder || recorder.state === 'inactive') { return resolve(); }
				recorder.onstop = resolve;
				recorder.stop();
			});
		}).then(function () {
			closeStage();
			if (dry) {
				cleanup();
				showPanel(aborted ? 'Test run cancelled' : 'Test run finished', '<p>Nothing was recorded, and the test data has been removed.</p>', [{ label: 'Close', onClick: hidePanel }]);
				return;
			}
			if (aborted) {
				cleanup();
				showPanel('Recording cancelled', '<p>Nothing was saved, and the test data has been removed.</p>', [{ label: 'Close', onClick: hidePanel }]);
				return;
			}
			var type = mime.split(';')[0];
			var blob = new Blob(chunks, { type: type });
			return saveVideo(blob, type, key).then(function (res) {
				return cleanup().then(function () {
					showPanel(t.title,
						'<video src="' + esc(res.url) + '" controls autoplay class="ymlk-preview"></video>' +
						(type.indexOf('mp4') === -1 ? '<p class="ymlk-warn">This browser saved the video as WebM instead of MP4. Update Chrome to get MP4 files.</p>' : ''),
						[
							{ label: 'Download', primary: true, href: res.url, download: true },
							{ label: 'Done', onClick: function () { window.location.reload(); } }
						]);
				});
			});
		}).catch(function (e) {
			aborted = true;
			try { if (recorder && recorder.state !== 'inactive') { recorder.stop(); } } catch (x) { /* ignore */ }
			closeStage();
			cleanup();
			if (e && e.name === 'NotAllowedError') {
				showPanel('Recording not started', '<p>Sharing was cancelled. Click Start Recording to try again.</p>', [{ label: 'Close', onClick: hidePanel }]);
				return;
			}
			showPanel('Something went wrong', '<p>' + esc(e && e.message ? e.message : e) + '</p><p>The test data has been removed. You can try again.</p>', [{ label: 'Close', onClick: hidePanel }]);
		});
	}

	/* ------------------------------------------------- Saving the video */
	// The video is sent in 5 MB pieces with a progress bar. A piece that fails is retried, and if saving
	// still fails the recording is never lost: you can try again or download it to your computer.
	function sendPiece(uploadId, index, piece, tries) {
		var fd = new FormData();
		fd.append('uploadId', uploadId);
		fd.append('index', index);
		fd.append('chunk', piece, 'piece.bin');
		var ctrl = window.AbortController ? new AbortController() : null;
		var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 120000) : null;
		return api('upload/chunk', { method: 'POST', body: fd, signal: ctrl ? ctrl.signal : undefined }).then(function (r) {
			clearTimeout(timer); return r;
		}, function (err) {
			clearTimeout(timer);
			if (tries >= 4) { throw new Error('The connection dropped while uploading (' + (err && err.message ? err.message : 'network error') + ').'); }
			return sleep(1500 * (tries + 1)).then(function () { return sendPiece(uploadId, index, piece, tries + 1); });
		});
	}
	function saveVideo(blob, type, key) {
		var ext = type.indexOf('mp4') !== -1 ? 'mp4' : 'webm';
		var size = 5 * 1024 * 1024, total = Math.max(1, Math.ceil(blob.size / size));
		var uploadId = (Date.now().toString(36) + Math.random().toString(36).slice(2, 10)).replace(/[^a-z0-9]/g, '');
		var mb = (blob.size / 1048576).toFixed(1);
		function progress(done) {
			var pct = Math.round(done / total * 100);
			showPanel('Saving video…', '<p>Uploading the recording to your Media Library (' + mb + ' MB). Please keep this page open.</p><div class="ymlk-progress"><span style="width:' + pct + '%"></span></div><p class="ymlk-progress-label">' + pct + '%</p>');
		}
		progress(0);
		var chain = Promise.resolve();
		for (var i = 0; i < total; i++) {
			(function (n) {
				chain = chain.then(function () {
					return sendPiece(uploadId, n, blob.slice(n * size, Math.min(blob.size, (n + 1) * size), type), 0).then(function () { progress(n + 1); });
				});
			})(i);
		}
		return chain.then(function () {
			showPanel('Saving video…', '<p>Almost done: adding the video to your Media Library.</p><div class="ymlk-progress"><span style="width:100%"></span></div>');
			return post('upload/finish', { uploadId: uploadId, total: total, tutorial: key, ext: ext });
		}).catch(function (e) {
			// Keep the recording: offer to retry, or to download it so nothing is lost.
			return new Promise(function (resolve, reject) {
				var local = URL.createObjectURL(blob);
				showPanel('The video could not be saved', '<p>' + esc(e && e.message ? e.message : e) + '</p><p>Your recording is not lost. Try again, or download it to your computer and upload it to the Media Library yourself.</p>', [
					{ label: 'Try again', primary: true, onClick: function () { saveVideo(blob, type, key).then(resolve, reject); } },
					{ label: 'Download to my computer', href: local, download: 'tutorial-' + key.replace(/_/g, '-') + '.' + ext },
					{ label: 'Close', onClick: function () { cleanup(); hidePanel(); } }
				]);
			});
		});
	}

	/* ---------------------------------------------------------------- Wiring */
	document.addEventListener('click', function (e) {
		var b = e.target.closest('.ymlk-tr-start');
		if (b) { e.preventDefault(); start(b.getAttribute('data-key')); return; }
		var del = e.target.closest('.ymlk-tr-del');
		if (del && window.confirm('Delete this video permanently?')) {
			api('video/' + del.getAttribute('data-id'), { method: 'DELETE' }).then(function () {
				var box = del.closest('.ymlk-tr-video');
				if (box) { box.remove(); }
			}).catch(function (err) { window.alert(err.message); });
		}
	});
})();
