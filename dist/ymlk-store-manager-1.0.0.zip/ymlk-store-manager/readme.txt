=== YMLK Store Manager ===
Contributors: ymlktechnologies
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

A simple, fast store-management app for WooCommerce shop owners.

== Description ==
Overview of sales, orders with one-tap status changes and WhatsApp contact, products with an easy sizes/colours builder, and stock control, in one mobile-friendly screen inside WordPress.

Developed by YMLK Technologies — https://ymlktechnologies.com

== Changelog ==
= 1.0.0 =
* First release.
